﻿using System;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capgemini.GreatOutdoor.UnitTests
{/// <summary>
/// developed by sravani
/// </summary>
    [TestClass]
    public class UpdateAdminBLTest
    {
        /// <summary>
        ///Update Admin in the Collection if the admin object is valid.
        /// </summary>
        [TestMethod]
        public async Task UpdateValidAdmin()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = await adminBL.GetAdminByAdminEmailBL("admin@capgemini.com");
            bool isAdded = false;

            string errorMessage = null;


            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Update Admin is not possible if the admin object is invalid.
        /// </summary>
        [TestMethod]
        public async Task Not_Updating_Invalid_Admin()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = new Admin() { AdminID = default(Guid), AdminName = "Scott", Email = "scott@gmail.com", Password = "Scott@123" };
            bool isAdded = false;

            string errorMessage = null;


            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        ///Update Admin password in the Collection if the admin current password is valid.
        /// </summary>
        [TestMethod]
        public async Task UpdateValidCurrentPassword()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("admin@capgemini.com", "Manager@12");
            bool isAdded = false;

            string errorMessage = null;


            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminPasswordBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }
        /// <summary>
        ///Not Updating Admin password in the Collection if the admin current password is Invalid.
        /// </summary>
        [TestMethod]
        public async Task Not_Updating_InvalidCurrentPassword()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("admin@capgemini.com", "manager");
            bool isAdded = false;

            string errorMessage = null;


            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminPasswordBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Admin Name can't be null
        /// </summary>
        [TestMethod]
        public async Task AdminNameCanNotBeNull()
        {
            //Arrange
            AdminBL AdminBL = new AdminBL();
            Admin Admin = new Admin() { AdminName = null, Password = "Smith123#", Email = "smith@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await AdminBL.UpdateAdminBL(Admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }



        /// <summary>
        /// Admin Email can't be null
        /// </summary>
        [TestMethod]
        public async Task AdminEmailCanNotBeNull()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = new Admin() { AdminName = "John", Password = "John123#", Email = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// AdminName should contain at least two characters
        /// </summary>
        [TestMethod]
        public async Task AdminNameShouldContainAtLeastTwoCharacters()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = new Admin() { AdminName = "J", Password = "John123#", Email = "john@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }



        /// <summary>
        /// Email should be a valid email as per regular expression
        /// </summary>
        [TestMethod]
        public async Task AdminEmailRegExp()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = new Admin() { AdminName = "John", Password = "John123#", Email = "john" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Admin Password can't be null
        /// </summary>
        [TestMethod]
        public async Task AdminPasswordCanNotBeNull()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = new Admin() { Password = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminPasswordBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// Password should be a valid password as per regular expression
        /// </summary>
        [TestMethod]
        public async Task AdminPasswordRegExp()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();
            Admin admin = new Admin() { Password = "John" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await adminBL.UpdateAdminPasswordBL(admin);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

    }
    [TestClass]
    public class GetAdminBLTest
    {
        /// <summary>
        /// Returns admin object, if Email and password are valid
        /// </summary>

        [TestMethod]
        public async Task GetAdminByEmailAndPasswordBLTest()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();

            //Act
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("admin@capgemini.com", "Manager@12");

            //Assert
            Assert.AreEqual(admin.AdminName, "Capgemini");
        }

        /// <summary>
        /// Returned object is null, if Email and password are invalid
        /// </summary>

        [TestMethod]
        public async Task GetAdminByInvalidEmailAndPasswordBLTest()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();

            //Act
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("admin@capgemini.com", "manager");

            //Assert
            Assert.AreEqual(admin, null);
        }
        /// <summary>
        /// returns null,if email is invalid
        /// </summary>

        [TestMethod]
        public async Task GetAdminByEmailBLTest()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();

            //Act
            Admin admin = await adminBL.GetAdminByAdminEmailBL("admin@capgemini.com");

            //Assert
            Assert.AreEqual(admin.AdminName, "Capgemini");
        }
        [TestMethod]
        public async Task GetAdminByInvalidEmailBLTest()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();

            //Act
            Admin admin = await adminBL.GetAdminByAdminEmailBL("admin@capgemini");

            //Assert
            Assert.AreEqual(admin, null);
        }

    }

}